Coffee by TEMPLATESIFY.COM
Email: templatesify@gmail.com
Designed by: Andy Suwandy

Coffee Template is Free for personal and commercial use under the CC BY License

Images provided in this example are sourced from pixabay.com
The licenses for those images are creative common license and can be used for commercial purpose.
For more details, please visit their website.

Credits:
- JQuery.com (JQuery Library)
- Responsive script (bytutorial.com)
- Sample Images from Pixabay.com